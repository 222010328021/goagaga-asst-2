const navItems = document.querySelectorAll('.nav-item');

navItems.forEach(item => {
    item.addEventListener('click', function() {
        alert(`You clicked on ${item.textContent}`);
    });
});

const searchButton = document.getElementById("search");

searchButton.addEventListener("click", function() {
    const destination = document.getElementById("destination").value;
    const checkin = document.getElementById("checkin").value;
    const checkout = document.getElementById("checkout").value;
    const guests = document.getElementById("guests").value;

    const apiKey = 'YOUR_API_KEY';
    const url = `https://api.expedia.com/hotels/v1/hotels?location=${destination}&startDate=${checkin}&endDate=${checkout}&room1=1&sort=price&pageNumber=1&pageSize=10&locale=en-US&currencyCode=USD&siteId=300&token=${apiKey}`;

    fetch(url)
        .then(response => response.json())
        .then(data => {
            const hotels = data.hotels;
            displayHotels(hotels);
        })
        .catch(error => console.error(error));
});

function displayHotels(hotels) {
    const results = document.getElementById("searchResults");
    results.innerHTML = '';

    if (hotels.length === 0) {
        results.innerHTML = '<p>No hotels found.</p>';
        return;
    }

    hotels.forEach(function(hotel) {
        const name = hotel.name;
        const price = hotel.ratePlan.price.current;
        const rating = hotel.starRating;

        const result = document.createElement("div");
        result.className = "card";
        result.innerHTML = `
      <div class="card-header">${name}</div>
      <div class="card-body">
        <p class="card-text">Price: $${price}</p>
        <p class="card-text">Rating: ${rating} stars</p>
      </div>
    `;

        results.appendChild(result);
    });
}

document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("show-container").addEventListener("click", function() {
        document.querySelector(".container").style.display = "block";
    });

    document.getElementById("hide-container").addEventListener("click", function() {
        document.querySelector(".container").style.display = "none";
    });
});